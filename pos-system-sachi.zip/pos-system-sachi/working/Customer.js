let customerArray = [];

// Save customer
$("#customersave").click(function () {
    let customerId = $("#CustomerId").val();
    let name = $("#name").val();
    let address = $("#address").val();
    let contact = $("#contact").val();

    // Check if all fields are filled
    if (!customerId || !name || !address || !contact) {
        alert("Please fill in all fields.");
        return;
    }

    let customer = {
        customerId: customerId,
        name: name,
        address: address,
        contact: contact
    };

    customerArray.push(customer);
    console.log(customerArray);
    loadCustomerTable();

    alert("Customer saved successfully!");

    // Clear form fields after saving
    $("#CustomerId").val('');
    $("#name").val('');
    $("#address").val('');
    $("#contact").val('');
});

// Table load method
const loadCustomerTable = () => {
    $("#customerTablebody").empty();

    customerArray.map((customer) => {
        let data = `<tr>
                     <td>${customer.customerId}</td>
                     <td>${customer.name}</td>
                     <td>${customer.address}</td>
                     <td>${customer.contact}</td>
                   </tr>`;

        $("#customerTablebody").append(data);
    });
};

// Clear form fields
$("#customerclr").click(function () {
    $("#CustomerId").val('');
    $("#name").val('');
    $("#address").val('');
    $("#contact").val('');
});

// Search function
$("#customersearchbtn").click(function (){
    // 1st
    let SerachValue = $("#customersearch").val();
    console.log(SerachValue);

    let ItemSNumber = parseInt(SerachValue);

    let ItemFound = false;

    for (let i = 0 ; i < customerArray.length ; i++){
        if (ItemSNumber === customerArray[i].customerId){
            ItemFound = true;

            $("#CustomerId").val(customerArray[i].customerId);
            $("#name").val(customerArray[i].name);
            $("#address").val(customerArray[i].address);
            $("#contact").val(customerArray[i].contact);

        }
    }


});